### JS在iOS中的简单运用
```
一、在当前应用中显示某个网页
   1. 在storyboard中拖入webView,设置约束
   2. 拖线
   3. 在viewDidLoad中加载网页 
      [self.webview loadHtmlString:@"<img src=\"123.png\">" baseURL:nil];
   4.加载某个特定网页
	  NSAppTransportSecurity 
	  NSAllowsArbitraryLoads
     *解析请求原理
      移动客户端  （发送请求，返回网页代码 ）服务器
     *三步加载一个网页
      http://v3.bootcss.com
      (有的公司应用很复杂，内部就三句代码)
     *响应缓慢，应该在前后加菊花，浏览webView的代理方法
     *做笔记：
      响应式设计、响应式布局（先百度）：@media
   5.提出需求：希望iOS端显示简洁的风格，把广告去除
     *设置代理
      // 网页加载完毕后调用（在这个方法中才能拿到所有的HTML元素）
      webViewDidFinishedLoad
      *提出如何在OC中调用js
       - 首先通过动态的切入脚本，在网页上测试删除
       var footer = document.getElementsByTagName('footer')[0];   footer.remove();
       连着写
       - 在OC中执行js代码
         *引导思考：在oc中执行js,要通过webView
         引出：stringByEvaluatingJavaScriptFromString 
       - 返回值，返回值的作用？
         function test() {return 10;} test();
         打印返回值：执行完最后一句js得到的值
         如果慢的话，执行：www.baidu.com
         用途：
          document.getElementById('userName').value;
          拿到用户的账号等信息，保存在本地沙盒，或者上传到服务器
        *举例子进一步说明：
         写一个登录界面：
            抽方法：testLoadHTML;
            加载login.html
            设置默认值：张三，在OC中打印张三
        *最后一个需求：如果加载公司的网页，可能一成不变，但是内容很多，第一次加载的时候缓存网页，写到沙盒中，方便下次使用
        - 拿到网页源代码
        - 判断沙盒中是否有用代码
        * 如何拿到网页用代码？
          document.getElementsByTagName('html')[0].innerHTML;
          打印：
             引入outerHTML
          写入沙盒：
             [html writeToFile:... atomically:YES encoding:NSUTF8StringEncoding error:nil];
             
         提出需求：如何在js中调用OC代码（目前不说，后面学多线程的时候会使用）
         - 加个  拍照  按钮，
         在OC中写个拍照方法，在html中如何调用：
         <button onclick="[self openCamera]">拍照</button> // 怎么办
         在安卓中可以直接调：this.openCamera;  
         
  整理笔记：
    1> 加载网页
    *加载网页源代码
       [webView loadHTMLString:@"<img src=\"123.png\">" baseURL:nil];
    *加载网页请求
       [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://baidu.com"]]];
    
    2> 利用webView执行js
    [webView stringByEvaluatingJavaScriptFromString:@"JS代码"];
      
```
