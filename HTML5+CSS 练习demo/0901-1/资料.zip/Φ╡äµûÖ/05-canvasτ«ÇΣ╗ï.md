### canvas简介
1. 回顾下上节课的知识点
2. 提出问题：如果执行的JS很长？
   *两次调用
   *拼接
   NSMutableString *js = [NSMutableString string];
   [js appendString:];
   ...
   [webView stringByEvaluatingJavaScriptFromString:];
   *方案：多个字符串之间用双引号隔开
   @“”“”“”
3. JS的绘图技术
   <canvas></canvas>
   <script>
      // 获取画布
      var canvas = document.getElementsByTagName('canvas')[0];
      // 获得上下文
      var ctx = canvas.getContext("2d");
      ctx.beginPath();
      
      ctx.strokeStyle = 'red';
      ctx.lineCap = 'round';
      ctx.lineWidth = 10;
      
      ctx.moveTo(10, 10);
      ctx.lineTo(100, 100); 
      
      ctx.lineTo(100, 20);
      ctx.closePath();     
   </script>
   
   *如果要更深入学习JS，可以百度JS库
   impress
