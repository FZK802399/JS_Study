回顾上节课上的内容
打开 w3cschool 可以学习更多东西

1.document的用途：
  1> 可以用来获得网页中的任何一个元素
  2> 可以创建HTML元素
  3>  ....
  
  document.write('');// 写一些内容，展示给学生看
  * 测试下内容会不会被覆盖
  
  提出需求:
  1.点击按钮，改变图片；
  升级：
  2.点击按钮，互相切换图片；
  
  通过getElementByID 引出
  getElementsByTagName
  getElementsByClassName
  getElementsByname
  分别切换图片
  function btnClick(){
     // 获取图片对象
     var icon = document.getElementById('icon');
     var icon = document.getElementsByTagName('img')[0];
     var icon = document.getElementsByClassName('tom')[0];
     var icon = document.getElementsByName('cat')[0];

     // 切换图片
     if (icon.src.indexof('test.png') == -1){
        icon.src = 'test.png';
     }else{
        icon.src = 'other.png';
     }
  }
  ID太多也不好，对比iOS尽量少使用tag,举例子：有些公司通过文档限定tag的取值
  
  
  另一种做法：
  全部用JS获取
  *注意点：调用方式
  
  
  3.其他的方法
  1> 点击图片
     var icon = document.getElementByTagName('img');
     icon.onclick = function(){
        console.log('点击了图片');
     };
   2> 点击body
     document.body.onclick = function (){
        console.log('点击了body');
     };
   3> 鼠标事件
      icon.onmousemove = function(){
         console.log('鼠标在图片上移动');
      };
      icon.onmouseover = function(){
         console.log('鼠标滑入图片');
      };
      icon.onmouseout = function(){
         console.log('鼠标滑出图片');
      };  
   
       icon.onkeyDown
       icon.onkeyUp
       
  4.倒计时函数
    <style>
        div{
            color: red;
            font-size: 100px;
        }

        img{
           display: none;
        }

    </style>
    <script>
         var timer = setInterval(function(){
           var div = document.getElementById('time');
           div.innerHTML = div.innerHTML - 1;
           if(div.innerHTML == '0'){
             // 停止计时
             clearInterval(timer);
            // 隐藏数字
             div.style.display ='none';
            // 显示图片
             var icon = document.getElementById('icon');
             icon.style.display = 'inline-block';
           }
         }, 1000);
    </script>
    
  总结：
  获取HTML元素的方式：
  *document.getElementById('icon');
  *document.getElementsByTagName(标签名);
  *document.getElementsByClassName(类名-class属性值);
  *document,getElementsByName(name的属性值);
  
     
       
       
       