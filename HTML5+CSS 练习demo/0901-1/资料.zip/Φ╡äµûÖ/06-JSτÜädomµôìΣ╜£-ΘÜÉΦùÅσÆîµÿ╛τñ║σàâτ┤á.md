1.用W3C分析JS学习重点
- JS HTML DOM
  利用JS可以进行DOM操作
  
2.代码演示
 <button>显示</button>
 <button>隐藏</button>
 <p>444444444444444444444444444<p>
 
 - 监听按钮点击:
  演示在行内显示, var age = 20; alert(age);
  
 - 在JS中实现方法:
 function show(){
   // 先打印
 }
 
 function hide(){
   // 先打印
 }
 
 // document相当于一颗DOM树
 
 - 查看一个对象里面所有属性
 
 

  