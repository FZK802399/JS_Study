## JS语法
```
要想把我们学习的JS运用到iOS开发中，我们还需要学习两个知识点：
两个内置对象：系统自带的对象，全局对象
// 内置对象：window 和 document

1.window的特点：
  1> 所有全局变量都是它的属性；
  2> 所有全局函数都是它的函数；
  
  var age = 20;
  
  function run(){
    var age = 20;<!--局部变量-->
    console.log('---run----');
  }
   
   run();
   window.run();
   window.run();
   window.run();
   
   console.log(age);
   console.log(window.age);
   // 把age变成局部变量
    做出区别
    
    alert('10');
    window.alert('10');
    // 当前函数属于哪个对象，this就代表这个对象
    function Dog(){
        console.log(this);
    }
    
    Dog(); // window.dog
    new Dog(); // 通过构造函数产生了一个新的对象，this代表这个狗对象
    
    
    function Dog(){
       this.alter('10'); //  
    }
    Dog();
    
    new Dog();
    
    /////
    var age = 20;
    function Dog(){
        console.log(this.age);
    }
    Dog();
    new Dog();
    
    ////////
    alter('10'); // 阻塞操作
    window.location.href = ''; // 通过这句代码改变浏览器的指向，实现用JS代码自动跳转；
    location.herf = '';
   
   总结笔记：
    
    掌握对象的函数调用：
     var result = 对象.函数名(参数值);
     
### 2.内置对象 - window
1> window的特点
   所有全局变量都是它的变量
   所有全局函数都是它的函数
2> 通过JS代码动态跳转页面
   location.href = 'http://www.baidu.com';
   window.loction.href = 'http://www.baidu.com';
    
```