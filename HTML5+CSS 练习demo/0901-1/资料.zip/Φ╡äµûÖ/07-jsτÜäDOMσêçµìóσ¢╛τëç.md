##JS切换图片
1.换一种方式绑定按钮
 在JS内部切换
 
2.其他事件方法
 移动 进去  出来


## 其他节点操作
1. 用外部样式来写
  测试:
  alter(1);
2. 不能外部\内部结合使用
  只要script中使用src属性引用了其他文件,就不能我往里面写JS
  
3. 节点的增删改查操作
 
 (1)  document.write()
  
 (2)  var img = document.createElement('img');
      img.src = 'images/icon_01.png';
      document.body.appendChild(img)
  
    // 创建多个标签
  
 (3) 往div中加个p标签
     var div = document.getElementById('content');
     var p = document.createElement('p');
    // 设置p标签里面的内容
     p.innerHTML = '123';
     div.appendChild(p);
     
  (4) 删除节点
     // 删除一个节点,要拿到父控件删除子控件
     var mj = document.getElementByClass..
     document.body.removeChild(mj)
     
     // CRUD
     // 增删改查
     
     // 如果父节点不是body
     mj.parentNode.removeChild(mj);
     
   (5) 查看body所有的节点
      var len = document.body.childNodes.length;
      for(var i=0; i<len; i++){
         var ele = list[i];
         alert(ele.tagName);
      }
      // 空白也算节点